start tables-only;
start seed;
start procedures;
start triggers;
